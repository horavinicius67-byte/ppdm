const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// configurar EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// arquivos estáticos (css, imagens, etc)
app.use(express.static(path.join(__dirname, "public")));

// base de dados fake
const produtos = [
  { id: 1, nome: "Notebook", descricao: "Notebook potente para estudo e trabalho", preco: 3500 },
  { id: 2, nome: "Mouse Gamer", descricao: "Mouse com 7200 DPI e RGB", preco: 150 },
  { id: 3, nome: "Teclado Mecânico", descricao: "Switch Blue, ideal para digitação", preco: 250 }
];

// rota lista de produtos
app.get("/produtos", (req, res) => {
  res.render("produtos", { produtos });
});

// rota compra
app.get("/compra/:id", (req, res) => {
  const produto = produtos.find(p => p.id == req.params.id);
  if (!produto) {
    return res.status(404).send("Produto não encontrado");
  }
  res.render("compra", { produto });
});

// rota inicial redireciona para produtos
app.get("/", (req, res) => {
  res.redirect("/produtos");
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
